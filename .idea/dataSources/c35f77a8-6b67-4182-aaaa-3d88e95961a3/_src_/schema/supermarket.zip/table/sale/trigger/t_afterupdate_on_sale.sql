CREATE TRIGGER `t_afterupdate_on_sale`
AFTER UPDATE ON `sale`
FOR EACH ROW
  BEGIN
    UPDATE stock
    SET number = number + old.number
    WHERE stockid = (SELECT stockid
                     FROM commodity
                     WHERE commodityid = old.commodityid);
    UPDATE account
    SET earning = earning - old.money
    WHERE managerid = old.operator;
    UPDATE account
    SET profit = profit - (SELECT stock.saleprice - storage.Inprice
                           FROM storage, stock
                           WHERE storage.commodityid = old.commodityid AND stock.stockid = (SELECT stockid
                                                                                            FROM commodity
                                                                                            WHERE commodityid =
                                                                                                  old.commodityid)) *
                          old.number
    WHERE managerid = old.operator;
    UPDATE stock
    SET number = number - new.number
    WHERE stockid = (SELECT stockid
                     FROM commodity
                     WHERE commodityid = new.commodityid);
    UPDATE account
    SET earning = earning + new.money
    WHERE managerid = new.operator;
    UPDATE account
    SET profit = profit + (SELECT stock.saleprice - storage.Inprice
                           FROM storage, stock
                           WHERE storage.commodityid = new.commodityid AND stock.stockid = (SELECT stockid
                                                                                            FROM commodity
                                                                                            WHERE commodityid =
                                                                                                  new.commodityid)) *
                          new.number
    WHERE managerid = new.operator;
  END