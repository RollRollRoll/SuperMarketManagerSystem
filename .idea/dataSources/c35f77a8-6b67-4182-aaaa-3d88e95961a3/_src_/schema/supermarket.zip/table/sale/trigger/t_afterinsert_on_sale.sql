CREATE TRIGGER `t_afterinsert_on_sale`
AFTER INSERT ON `sale`
FOR EACH ROW
  BEGIN
    UPDATE stock
    SET number = number - new.number
    WHERE stockid = (SELECT stockid
                     FROM commodity
                     WHERE commodityid = new.commodityid);
    UPDATE account
    SET earning = earning + new.money
    WHERE managerid = new.operator;
    UPDATE account
    SET profit = profit + (SELECT stock.saleprice - storage.Inprice
                           FROM storage, stock
                           WHERE storage.commodityid = new.commodityid AND stock.stockid = (SELECT stockid
                                                                                            FROM commodity
                                                                                            WHERE commodityid =
                                                                                                  new.commodityid)) *
                          new.number
    WHERE managerid = new.operator;
  END