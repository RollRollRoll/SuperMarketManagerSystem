CREATE TRIGGER `t_afterinsert_on_storage`
AFTER INSERT ON `storage`
FOR EACH ROW
  BEGIN
    UPDATE stock
    SET number = number + new.number
    WHERE stockid = (SELECT stockid
                     FROM commodity
                     WHERE commodityid = new.commodityid);
  END