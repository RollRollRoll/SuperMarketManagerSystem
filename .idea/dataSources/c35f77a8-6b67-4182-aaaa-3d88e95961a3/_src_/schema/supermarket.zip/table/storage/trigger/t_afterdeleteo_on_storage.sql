CREATE TRIGGER `t_afterdeleteo_on_storage`
AFTER DELETE ON `storage`
FOR EACH ROW
  BEGIN
    UPDATE stock
    SET number = number - old.number
    WHERE stockid = (SELECT stockid
                     FROM commodity
                     WHERE commodityid = old.commodityid);
  END