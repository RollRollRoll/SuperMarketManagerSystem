CREATE TRIGGER `t_afterupdate_on_storage`
AFTER UPDATE ON `storage`
FOR EACH ROW
  BEGIN
    IF new.number != old.number
    THEN
      UPDATE stock
      SET number = number - old.number
      WHERE stockid = (SELECT stockid
                       FROM commodity
                       WHERE commodityid = old.commodityid);
      UPDATE stock
      SET number = number + new.number
      WHERE stockid = (SELECT stockid
                       FROM commodity
                       WHERE commodityid = old.commodityid);
    END IF;
  END